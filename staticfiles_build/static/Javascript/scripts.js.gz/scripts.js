const sidebar = document.getElementById("sidebar") 
document.getElementById("show").addEventListener("click",  function(){ 
    sidebar.style.display = "block"
 });
 document.getElementById("hide").addEventListener("click",  function(){ 
    sidebar.style.display = "none"
 });